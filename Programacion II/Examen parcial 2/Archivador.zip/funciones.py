#
#
#
from Mascota import Mascota
from Gato import Gato
from datos import habitat, animal, horaD_Comida
import random

class Funciones:
   def __init__(self):
      self.listaMascotas = {}
      pass
#TODO: Hacer una funcion para mostrar la lista de mascotas con sus atributos sin usar "for" o "while"
   def mostrar_lista(lista):
      return  print(listaMascotas, sep ='\n')
#TODO: Hacer una funcion para crear una lista con las mascotas agregando mascotas nuevas a listaMascotas
   def crear_lista(lista, creacion):
      habitat = random.choice(datos.habitat)
      animal = random.choice(datos.animal)
      horaD_Comida = random.choice(datos.horaD_Comida)
      color = random.choice(datos.color)
#TODO: agregar las nuevas mascotas a las listas
      listaMascotas[animal] : animal[habitat, color, horaD_Comida]
      pass
#TODO: hacer una funcion para contar las mascotas de la lista ya creada
   def contar_mascotas(lista):
      return len.listaMascotas
   
   def menu_1(self):
      respuesta = int(input("""[1] Mostrar una lista con todas tus mascotas
[2] Agregar mas mascotas a tu lista
[3] Mostrar el numero de mascotas en tu lista
[4] Salir
"""))
      match respuesta:
         case 1:
            a = mostrar_lista()
            print(a)

         case 2:
            pass
         case 3:
            pass
         case 4:
            print("gracias por usar mi programa, nos vemos!")
            #break

def darBienvenida():
   print("""Hola Adrian, bienvenido a mi programa 
para organizar a tus mascotas favoritas, 
empecemos que te gustaria hacer?
""")



