from funciones import Funciones
from funciones import darBienvenida


a = darBienvenida()
print(a)



